import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Droplets,
  TrendingDown,
  AlertCircle,
  CheckCircle2,
  Clock,
  BarChart3,
  ArrowUpRight,
  MapPin,
} from "lucide-react";
import { Link } from "react-router-dom";

const summaryCards = [
  {
    title: "Water Saved",
    value: "12,450",
    unit: "gallons",
    change: "+15.2%",
    icon: Droplets,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    title: "Issues Reported",
    value: "24",
    unit: "reports",
    change: "+3 this week",
    icon: AlertCircle,
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    title: "Issues Resolved",
    value: "18",
    unit: "fixed",
    change: "75% rate",
    icon: CheckCircle2,
    color: "text-secondary",
    bgColor: "bg-secondary/10",
  },
  {
    title: "Active Reports",
    value: "6",
    unit: "pending",
    change: "2 urgent",
    icon: Clock,
    color: "text-orange-500",
    bgColor: "bg-orange-500/10",
  },
];

const recentReports = [
  {
    id: 1,
    title: "Leaking fire hydrant",
    location: "123 Main St",
    status: "pending",
    date: "2 hours ago",
  },
  {
    id: 2,
    title: "Broken sprinkler system",
    location: "456 Oak Ave",
    status: "in-progress",
    date: "5 hours ago",
  },
  {
    id: 3,
    title: "Water main leak",
    location: "789 Pine Rd",
    status: "resolved",
    date: "1 day ago",
  },
  {
    id: 4,
    title: "Overflowing drainage",
    location: "321 Elm St",
    status: "resolved",
    date: "2 days ago",
  },
];

const getStatusBadge = (status: string) => {
  switch (status) {
    case "pending":
      return (
        <span className="px-3 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-700">
          Pending
        </span>
      );
    case "in-progress":
      return (
        <span className="px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
          In Progress
        </span>
      );
    case "resolved":
      return (
        <span className="px-3 py-1 rounded-full text-xs font-medium bg-secondary/10 text-secondary">
          Resolved
        </span>
      );
    default:
      return null;
  }
};

export default function Dashboard() {
  return (
    <Layout>
      <div className="min-h-screen bg-background py-12">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-10">
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">
              Dashboard
            </h1>
            <p className="text-muted-foreground">
              Track your water conservation impact and community reports.
            </p>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            {summaryCards.map((card, index) => (
              <Card
                key={card.title}
                className="shadow-card border-border/50 hover:shadow-glow transition-all duration-300 animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className={`p-3 rounded-xl ${card.bgColor}`}
                    >
                      <card.icon className={`h-6 w-6 ${card.color}`} />
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {card.change}
                    </span>
                  </div>
                  <div className="space-y-1">
                    <div className="text-3xl font-display font-bold text-foreground">
                      {card.value}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {card.title} ({card.unit})
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Recent Reports */}
            <div className="lg:col-span-2">
              <Card className="shadow-card border-border/50">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="font-display text-xl">
                    Recent Reports
                  </CardTitle>
                  <Link to="/report">
                    <Button variant="outline" size="sm" className="group">
                      New Report
                      <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </Button>
                  </Link>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentReports.map((report) => (
                      <div
                        key={report.id}
                        className="flex items-center justify-between p-4 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex-1">
                          <h4 className="font-semibold text-foreground mb-1">
                            {report.title}
                          </h4>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <MapPin className="h-3.5 w-3.5" />
                            <span>{report.location}</span>
                            <span className="text-border">•</span>
                            <span>{report.date}</span>
                          </div>
                        </div>
                        {getStatusBadge(report.status)}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions & Stats */}
            <div className="space-y-6">
              {/* Quick Actions */}
              <Card className="shadow-card border-border/50">
                <CardHeader>
                  <CardTitle className="font-display text-xl">
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Link to="/report" className="block">
                    <Button variant="default" className="w-full justify-start">
                      <AlertCircle className="h-4 w-4 mr-2" />
                      Report New Issue
                    </Button>
                  </Link>
                  <Link to="/tips" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <TrendingDown className="h-4 w-4 mr-2" />
                      View Saving Tips
                    </Button>
                  </Link>
                  <Button variant="ghost" className="w-full justify-start">
                    <BarChart3 className="h-4 w-4 mr-2" />
                    View Full Analytics
                  </Button>
                </CardContent>
              </Card>

              {/* Conservation Progress */}
              <Card className="shadow-card border-border/50 gradient-ocean text-primary-foreground">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-lg bg-primary-foreground/20">
                      <Droplets className="h-5 w-5" />
                    </div>
                    <span className="font-semibold">This Month's Goal</span>
                  </div>
                  <div className="mb-4">
                    <div className="text-4xl font-display font-bold mb-1">
                      78%
                    </div>
                    <p className="text-primary-foreground/70 text-sm">
                      15,000 / 20,000 gallons saved
                    </p>
                  </div>
                  <div className="w-full h-2 rounded-full bg-primary-foreground/20 overflow-hidden">
                    <div
                      className="h-full bg-primary-foreground rounded-full transition-all duration-500"
                      style={{ width: "78%" }}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
