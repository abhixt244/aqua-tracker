import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Droplets,
  Home,
  Leaf,
  Building2,
  ShowerHead,
  Utensils,
  Trees,
  Lightbulb,
  CheckCircle,
} from "lucide-react";

const categories = [
  { id: "all", label: "All Tips", icon: Lightbulb },
  { id: "home", label: "At Home", icon: Home },
  { id: "garden", label: "Garden", icon: Leaf },
  { id: "bathroom", label: "Bathroom", icon: ShowerHead },
  { id: "kitchen", label: "Kitchen", icon: Utensils },
  { id: "outdoor", label: "Outdoor", icon: Trees },
];

const tips = [
  {
    id: 1,
    title: "Fix Leaky Faucets Promptly",
    content:
      "A dripping faucet can waste up to 3,000 gallons of water per year. Check all faucets regularly and replace worn washers immediately.",
    category: "home",
    savings: "3,000 gal/year",
    icon: Home,
  },
  {
    id: 2,
    title: "Take Shorter Showers",
    content:
      "Reduce your shower time by 2 minutes to save up to 5 gallons of water. Consider using a timer to track your shower duration.",
    category: "bathroom",
    savings: "1,825 gal/year",
    icon: ShowerHead,
  },
  {
    id: 3,
    title: "Water Plants in the Morning",
    content:
      "Watering during cooler morning hours reduces evaporation. Your plants absorb more water and you use less overall.",
    category: "garden",
    savings: "Up to 25% less",
    icon: Leaf,
  },
  {
    id: 4,
    title: "Use a Dishwasher Efficiently",
    content:
      "Only run your dishwasher when it's full. Modern dishwashers use less water than hand-washing when used correctly.",
    category: "kitchen",
    savings: "5,000 gal/year",
    icon: Utensils,
  },
  {
    id: 5,
    title: "Install Low-Flow Showerheads",
    content:
      "Low-flow showerheads can reduce water usage by 40% while still providing good pressure. Easy to install and cost-effective.",
    category: "bathroom",
    savings: "8,000 gal/year",
    icon: ShowerHead,
  },
  {
    id: 6,
    title: "Collect Rainwater",
    content:
      "Use rain barrels to collect water for your garden. This free water source can significantly reduce your outdoor water usage.",
    category: "outdoor",
    savings: "1,300 gal/year",
    icon: Trees,
  },
  {
    id: 7,
    title: "Turn Off While Brushing",
    content:
      "Don't let the water run while brushing your teeth. You can save up to 8 gallons of water per day with this simple habit.",
    category: "bathroom",
    savings: "2,920 gal/year",
    icon: ShowerHead,
  },
  {
    id: 8,
    title: "Use Mulch in Gardens",
    content:
      "Apply mulch around plants to retain moisture and reduce evaporation. This can cut watering needs by up to 50%.",
    category: "garden",
    savings: "50% reduction",
    icon: Leaf,
  },
  {
    id: 9,
    title: "Check Toilet for Leaks",
    content:
      "Add food coloring to your toilet tank. If color appears in the bowl without flushing, you have a leak that needs fixing.",
    category: "bathroom",
    savings: "200 gal/day",
    icon: Home,
  },
  {
    id: 10,
    title: "Sweep, Don't Hose",
    content:
      "Use a broom instead of a hose to clean driveways and sidewalks. This simple switch can save 150 gallons each time.",
    category: "outdoor",
    savings: "150 gal/use",
    icon: Trees,
  },
  {
    id: 11,
    title: "Wash Full Loads Only",
    content:
      "Wait until you have a full load before running your washing machine. This maximizes efficiency and minimizes water waste.",
    category: "home",
    savings: "3,400 gal/year",
    icon: Home,
  },
  {
    id: 12,
    title: "Choose Native Plants",
    content:
      "Native plants are adapted to your local climate and typically require less watering than exotic species.",
    category: "garden",
    savings: "30% reduction",
    icon: Leaf,
  },
];

export default function Tips() {
  const [activeCategory, setActiveCategory] = useState("all");

  const filteredTips =
    activeCategory === "all"
      ? tips
      : tips.filter((tip) => tip.category === activeCategory);

  return (
    <Layout>
      <div className="min-h-screen bg-background">
        {/* Hero */}
        <section className="py-16 gradient-wave">
          <div className="container mx-auto px-4 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 text-secondary mb-4">
              <Lightbulb className="h-4 w-4" />
              <span className="text-sm font-medium">Conservation Tips</span>
            </div>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground mb-4">
              Water-Saving Tips & Tricks
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Discover practical ways to reduce your water consumption at home,
              in the garden, and beyond.
            </p>
          </div>
        </section>

        {/* Category Filter */}
        <section className="py-8 border-b border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap gap-3 justify-center">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={activeCategory === category.id ? "default" : "outline"}
                  onClick={() => setActiveCategory(category.id)}
                  className="gap-2"
                >
                  <category.icon className="h-4 w-4" />
                  {category.label}
                </Button>
              ))}
            </div>
          </div>
        </section>

        {/* Tips Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTips.map((tip, index) => (
                <Card
                  key={tip.id}
                  className="shadow-card border-border/50 hover:shadow-glow hover:border-primary/30 transition-all duration-500 group animate-fade-in"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 rounded-xl gradient-ocean flex items-center justify-center shadow-soft group-hover:scale-110 transition-transform duration-300">
                        <tip.icon className="h-6 w-6 text-primary-foreground" />
                      </div>
                      <span className="px-3 py-1 rounded-full bg-secondary/10 text-secondary text-xs font-semibold">
                        Save {tip.savings}
                      </span>
                    </div>
                    <h3 className="text-lg font-display font-bold text-foreground mb-2">
                      {tip.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {tip.content}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Quick Facts */}
        <section className="py-16 gradient-hero">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-display font-bold text-primary-foreground mb-4">
                Did You Know?
              </h2>
              <p className="text-primary-foreground/70">
                Fascinating facts about water conservation
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center p-6 rounded-2xl bg-primary-foreground/10 border border-primary-foreground/20">
                <Droplets className="h-10 w-10 text-accent mx-auto mb-4" />
                <div className="text-3xl font-display font-bold text-primary-foreground mb-2">
                  97%
                </div>
                <p className="text-primary-foreground/70 text-sm">
                  of Earth's water is saltwater and can't be used directly
                </p>
              </div>
              <div className="text-center p-6 rounded-2xl bg-primary-foreground/10 border border-primary-foreground/20">
                <Building2 className="h-10 w-10 text-accent mx-auto mb-4" />
                <div className="text-3xl font-display font-bold text-primary-foreground mb-2">
                  30%
                </div>
                <p className="text-primary-foreground/70 text-sm">
                  of household water is used for outdoor purposes
                </p>
              </div>
              <div className="text-center p-6 rounded-2xl bg-primary-foreground/10 border border-primary-foreground/20">
                <CheckCircle className="h-10 w-10 text-accent mx-auto mb-4" />
                <div className="text-3xl font-display font-bold text-primary-foreground mb-2">
                  50%
                </div>
                <p className="text-primary-foreground/70 text-sm">
                  reduction is possible with simple daily changes
                </p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
