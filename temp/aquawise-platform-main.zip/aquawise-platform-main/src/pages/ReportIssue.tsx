import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertTriangle,
  MapPin,
  Camera,
  Send,
  CheckCircle,
  Info,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const issueTypes = [
  { value: "leak", label: "Water Leak" },
  { value: "waste", label: "Water Waste" },
  { value: "overflow", label: "Overflow/Flooding" },
  { value: "hydrant", label: "Fire Hydrant Issue" },
  { value: "sprinkler", label: "Sprinkler Problem" },
  { value: "other", label: "Other" },
];

const urgencyLevels = [
  { value: "low", label: "Low - Minor issue" },
  { value: "medium", label: "Medium - Needs attention" },
  { value: "high", label: "High - Urgent action needed" },
];

export default function ReportIssue() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setIsSubmitted(true);

    toast({
      title: "Report Submitted!",
      description: "Thank you for helping conserve water. We'll review your report shortly.",
    });
  };

  if (isSubmitted) {
    return (
      <Layout>
        <div className="min-h-screen bg-background py-24">
          <div className="container mx-auto px-4">
            <Card className="max-w-lg mx-auto shadow-card border-border/50 text-center">
              <CardContent className="pt-12 pb-8">
                <div className="w-20 h-20 rounded-full bg-secondary/10 flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="h-10 w-10 text-secondary" />
                </div>
                <h2 className="text-2xl font-display font-bold text-foreground mb-3">
                  Report Submitted Successfully!
                </h2>
                <p className="text-muted-foreground mb-8">
                  Thank you for contributing to water conservation. Our team will
                  review your report and take appropriate action.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button
                    variant="default"
                    onClick={() => setIsSubmitted(false)}
                  >
                    Submit Another Report
                  </Button>
                  <Button variant="outline" asChild>
                    <a href="/dashboard">View Dashboard</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-background py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            {/* Header */}
            <div className="text-center mb-10">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-destructive/10 text-destructive mb-4">
                <AlertTriangle className="h-4 w-4" />
                <span className="text-sm font-medium">Report Water Issues</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-3">
                Report a Water Issue
              </h1>
              <p className="text-muted-foreground">
                Help us identify and fix water waste in your community.
              </p>
            </div>

            {/* Form Card */}
            <Card className="shadow-card border-border/50">
              <CardHeader>
                <CardTitle className="font-display flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  Issue Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Title */}
                  <div className="space-y-2">
                    <Label htmlFor="title">Issue Title *</Label>
                    <Input
                      id="title"
                      placeholder="Brief description of the issue"
                      required
                      className="h-12"
                    />
                  </div>

                  {/* Issue Type & Urgency */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Issue Type *</Label>
                      <Select required>
                        <SelectTrigger className="h-12">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          {issueTypes.map((type) => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Urgency Level *</Label>
                      <Select required>
                        <SelectTrigger className="h-12">
                          <SelectValue placeholder="Select urgency" />
                        </SelectTrigger>
                        <SelectContent>
                          {urgencyLevels.map((level) => (
                            <SelectItem key={level.value} value={level.value}>
                              {level.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Location */}
                  <div className="space-y-2">
                    <Label htmlFor="location">Location *</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <Input
                        id="location"
                        placeholder="Enter address or use current location"
                        required
                        className="h-12 pl-11"
                      />
                    </div>
                  </div>

                  {/* Description */}
                  <div className="space-y-2">
                    <Label htmlFor="description">Description *</Label>
                    <Textarea
                      id="description"
                      placeholder="Provide more details about the issue, including how long it's been happening..."
                      required
                      rows={5}
                      className="resize-none"
                    />
                  </div>

                  {/* Image Upload */}
                  <div className="space-y-2">
                    <Label>Photo Evidence (Optional)</Label>
                    <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
                      <Camera className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                      <p className="text-sm text-muted-foreground mb-1">
                        Drag and drop an image, or click to browse
                      </p>
                      <p className="text-xs text-muted-foreground/70">
                        PNG, JPG up to 10MB
                      </p>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    variant="hero"
                    size="lg"
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <span className="animate-spin mr-2">⏳</span>
                        Submitting...
                      </>
                    ) : (
                      <>
                        <Send className="h-5 w-5 mr-2" />
                        Submit Report
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Tips */}
            <div className="mt-8 p-6 rounded-xl bg-primary/5 border border-primary/20">
              <h3 className="font-display font-semibold text-foreground mb-3 flex items-center gap-2">
                <Info className="h-5 w-5 text-primary" />
                Tips for Effective Reporting
              </h3>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Be as specific as possible about the location</li>
                <li>• Include photos when possible for faster response</li>
                <li>• Estimate the severity and duration of the issue</li>
                <li>• Provide contact info if you're available for follow-up</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
