import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import {
  Droplets,
  TrendingDown,
  Users,
  AlertTriangle,
  Lightbulb,
  BarChart3,
  ArrowRight,
  CheckCircle,
} from "lucide-react";

const stats = [
  { value: "2.1B", label: "People lack safe water", icon: Users },
  { value: "70%", label: "Water used in agriculture", icon: TrendingDown },
  { value: "6B", label: "Gallons lost daily", icon: Droplets },
];

const features = [
  {
    icon: AlertTriangle,
    title: "Report Issues",
    description:
      "Quickly report water waste, leaks, or issues in your community with geo-tagging support.",
    link: "/report",
  },
  {
    icon: Lightbulb,
    title: "Learn & Save",
    description:
      "Access expert tips and practical guides to reduce your water footprint at home and work.",
    link: "/tips",
  },
  {
    icon: BarChart3,
    title: "Track Impact",
    description:
      "Monitor your water conservation efforts and see the collective community impact.",
    link: "/dashboard",
  },
];

const benefits = [
  "Real-time issue tracking and resolution",
  "Community-driven conservation efforts",
  "Expert-verified water-saving tips",
  "Personal and community dashboards",
  "Gamified conservation challenges",
  "Local authority integration",
];

export default function Home() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center gradient-hero overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-secondary/20 rounded-full blur-3xl animate-wave" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-foreground/10 border border-primary-foreground/20 mb-8 animate-fade-in">
              <Droplets className="h-4 w-4 text-accent" />
              <span className="text-sm text-primary-foreground/80">
                Join 50,000+ water guardians
              </span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold text-primary-foreground mb-6 animate-fade-in [animation-delay:100ms]">
              Every Drop Counts.
              <br />
              <span className="text-accent">Save Water Today.</span>
            </h1>

            <p className="text-lg md:text-xl text-primary-foreground/70 mb-10 max-w-2xl mx-auto animate-fade-in [animation-delay:200ms]">
              A community-powered platform to report water issues, learn conservation
              strategies, and track your impact on protecting our planet's most
              precious resource.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in [animation-delay:300ms]">
              <Link to="/auth">
                <Button variant="glass" size="xl" className="group">
                  Get Started Free
                  <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
              <Link to="/tips">
                <Button
                  variant="ghost"
                  size="xl"
                  className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10"
                >
                  Explore Tips
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Wave divider */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg
            viewBox="0 0 1440 120"
            className="w-full h-24 fill-background"
            preserveAspectRatio="none"
          >
            <path d="M0,40 C480,120 960,0 1440,80 L1440,120 L0,120 Z" />
          </svg>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {stats.map((stat, index) => (
              <div
                key={stat.label}
                className="text-center p-8 rounded-2xl gradient-card shadow-card border border-border/50 animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <stat.icon className="h-10 w-10 text-primary mx-auto mb-4" />
                <div className="text-4xl md:text-5xl font-display font-bold text-gradient mb-2">
                  {stat.value}
                </div>
                <p className="text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 gradient-wave">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">
              How AquaSave Works
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our platform makes it easy to contribute to water conservation efforts
              in your community.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Link
                key={feature.title}
                to={feature.link}
                className="group p-8 rounded-2xl bg-card shadow-card border border-border/50 hover:shadow-glow hover:border-primary/30 transition-all duration-500 animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-14 h-14 rounded-xl gradient-ocean flex items-center justify-center mb-6 shadow-soft group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="h-7 w-7 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-display font-bold text-foreground mb-3">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-6">
                Why Choose <span className="text-gradient">AquaSave?</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Join thousands of individuals, communities, and organizations making a
                real difference in water conservation.
              </p>
              <ul className="space-y-4">
                {benefits.map((benefit, index) => (
                  <li
                    key={index}
                    className="flex items-center gap-3 animate-slide-in-left"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <CheckCircle className="h-5 w-5 text-secondary flex-shrink-0" />
                    <span className="text-foreground">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-3xl gradient-ocean p-1 shadow-glow">
                <div className="w-full h-full rounded-3xl bg-card flex items-center justify-center">
                  <div className="text-center p-8">
                    <div className="w-24 h-24 mx-auto mb-6 rounded-2xl gradient-ocean flex items-center justify-center animate-float">
                      <Droplets className="h-12 w-12 text-primary-foreground" />
                    </div>
                    <h3 className="text-2xl font-display font-bold text-foreground mb-2">
                      Start Saving Today
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      Make your first contribution to water conservation
                    </p>
                    <Link to="/auth">
                      <Button variant="hero">Join Now</Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 gradient-hero">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-primary-foreground mb-6">
            Ready to Make a Difference?
          </h2>
          <p className="text-lg text-primary-foreground/70 max-w-2xl mx-auto mb-10">
            Join our growing community of water guardians and help protect Earth's
            most precious resource.
          </p>
          <Link to="/auth">
            <Button variant="glass" size="xl" className="group">
              Create Free Account
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Button>
          </Link>
        </div>
      </section>
    </Layout>
  );
}
